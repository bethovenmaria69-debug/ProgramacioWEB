<?php

include 'conn.php';

// variables con los datos del formulario
$usuario = 'Sam';
$password = '124';
$Nombre = 'Bonny';
$Correo = '@dkfjfj';
$Telefono = '6236363';


$stmt = $conn ->prepare ("INSERT INTO clientes (usuario,password,nombre,correo,telefono) VALUES (?, ?, ?, ?, ?)");

if ($stmt=== false) {

        die("Error al preparara la consulta: " . $conn-> error);       
}

// vincular los parametros a la consulta preparada (s=string, i=integer, etc.)
$stmt ->bind_param("sssss",$usuario,$password,$Nombre,$Correo,$Telefono);


if ($stmt -> execute()) {

    echo " Nuevo registro creado correctamente. Con el ID: " . $stmt->insert_id;
}else{
    echo "Error al ejecutar la consulta: " . $stmt->error;
}
?>
