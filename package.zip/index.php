<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>banco_db</title>
</head>

<body>
    <!--
    <h1>Hola mundo.Esta es mi primer aplicacion web con electron !   :) </h1>
    <h3>Lo siguiente es una lista que podemos usar en nuestra aplicacion: </h3>
    <ul>
        <li>Botones</li>
        <li>Tablas</li>
        <li>Formularios</li>
     </ul>
    -->

</body>
</html> 



<?php
    
    include 'conn.php';
    //include 'insertClientes.php';
    include 'consultas.php'; 
    //include 'login.php';
    //include 'registro.php';
    
?>