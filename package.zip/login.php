<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccesoClientes</title>
</head>
<body>
    <form action="controlLogin.php" method="post">

        <input type="text" name="usuario" id="usuario" placeholder="Usuario" required>
        <input type="password" name="contrasena" id="contrasena" placeholder="Contraseña" required>
        <button type="submit">Ingresar</button>

    </form>


</body>
</html>