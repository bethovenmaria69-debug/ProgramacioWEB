<?php
require_once 'conn.php';

    if($_SERVER['REQUEST_METHOD'] === "POST"){
        $usuario = $_POST['usuario'];
        $contrasena = $_POST['contrasena'];

        $stmt = $conn->prepare("SELECT * FROM clientes WHERE usuario = ?");
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if($resultado->num_rows > 0){
            $fila = $resultado->fetch_assoc();
    
            if(password_verify($contrasena, $fila['password'])) {
                echo"Inicio de sesion exitoso";
            }else{
                echo "Contrasena Incorrecta";
            }
        }else{
            echo " Usuario no encontrado";
        }


    } else{
        echo "Acceso no autorizado";
    }

    $stmt ->close();
    $conn ->close();
?>

