<?php
include 'conn.php';
$rConsultaEstatus = $conn->query("SELECT * FROM estatus");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro</title>
    </head>
    <body>
       
        <form action="guardarRegistro.php" method="post">

            <input type="text" name="usuario" id="usuario" required placeholder="Usuario"><br><br>
            <input type="password" name="contrasena" id="contrasena" required placeholder="Contraseña"><br><br>
            <input type="text" name="nombre" id = "nombre" required placeholder="Nombre"><br><br>
            <input type="email" name="correo" id = "correo" required placeholder="Correo"><br><br>
            <input type="text" name="telefono" id = "telefono" required placeholder="Telefono"><br><br>
        
            <?php
                $rConsultaUsrs = $conn->query("SELECT * FROM estatus");

                if($rConsultaUsrs === false){
                    die("Error de consulta SQL: " . $conn->error);
                }

                if($rConsultaUsrs->num_rows === 0) {
                    echo "No se encontraron resultados en la tabla 'estatus'";
                }else{
            ?>
                <select id="estado" name = "estado">
            <?php
                while($row = $rConsultaUsrs->fetch_assoc()){
            ?>
                <option value="<?php echo $row['id']; ?>"><?php echo $row['nombre']; ?></option>
            
            <?php
                }
            ?>
                 </select>
            <?php

            }
            ?>
                <br><br>
                <button type="submit">guardar</button>
        </form>

       
    
    </body>
</html>