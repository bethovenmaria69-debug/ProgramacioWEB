<?php
    //include 'conn.php';
    //consulta a sql
    $sqlConsultacuentas = $conn->query("SELECT * FROM clientes");
    //$sqlConsultapruebas = new mysqli($host, $user, $password, $database)->query("SELECT * FROM pruebas");
    //$sqlConsultapruebas = new mysqli("localhost", "martinezanch", "contr@s3n54", "pruebadb")->query("SELECT * FROM pruebas");

    //Verifica errores
    if($sqlConsultacuentas === false){
    die("Error de consulta SQL: " . $conn->error);
    }


    if($sqlConsultacuentas->num_rows === 0) {
        echo "No se encontraron clientes registrados'";
    }
    else{
        
           // echo "ID: " . $fila["id"] . " Usuario: " . $fila["usuario"] . " -Password: " . $fila["password"];
            ?>
        <table border="1">
            <tr>
                <td>ID cliente</td>
                <td>Usuario</td>
                <td>Password</td>
                <td>Nombre</td>
                <td>Correo</td>
                <td>Telefono</td>
            </tr>
<?php
            while($fila = $sqlConsultacuentas->fetch_assoc()){
?>
            <tr>
                
                <td><?php echo $fila["id_cliente"]; ?></td>
                <td><?php echo $fila["usuario"]; ?></td>
                <td><?php echo $fila["password"]; ?></td>
                <td><?php echo $fila["nombre"]; ?></td>
                <td><?php echo $fila["correo"]; ?></td>
                <td><?php echo $fila["telefono"]; ?></td>

            </tr>
        

<?php
    } // Fin del while
?>

</table>

<?php
} // Fin del if
?>


