const {app, BrowserWindow} = require ('electron');


const createWindow = () => {
    const win = new BrowserWindow({
        width: 800,
        height: 600
    });

    //win.loadFile('index.html')
    win.loadURL('http://localhost/EVALUATIVO02/index.php');
    //http://localhost/repertrack_copia/index.php
};

app.whenReady().then(() => {
    createWindow()
});