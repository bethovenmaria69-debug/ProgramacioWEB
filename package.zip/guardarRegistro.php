<?php

include 'conn.php';

//echo "si llego";

$usuario = $_POST['usuario'];
$contrasena = password_hash($_POST['contrasena'], PASSWORD_BCRYPT);
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];

echo "usuario: ".$usuario."<br>";
echo "contraseña: ".$contrasena."<br>";
echo "nombre: ".$nombre."<br>";
echo "correo: ".$correo."<br>";
echo "telefono: ".$telefono."<br>";


$stmt = $conn->prepare("INSERT INTO clientes (usuario,password,nombre,correo,telefono) VALUES (?, ?, ?, ?, ?)");

if($stmt === false){
    die("Error al preparar la consulta: ".$conn->error);
}


$stmt->bind_param("sssss",$usuario,$contrasena,$nombre,$correo,$telefono);


if($stmt->execute()){
    echo "Nuevo registro creado correctamente. Con el ID: ".$stmt->insert_id;
}else{
    echo "Error al ejecutar la consulta: ".$stmt->error;
}

?>
