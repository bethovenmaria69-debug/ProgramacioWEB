<?php
    //include 'conn.php';
    //consulta a sql
    $sqlConsultausuarios = $conn->query("SELECT * FROM usuarios");
    //$sqlConsultapruebas = new mysqli($host, $user, $password, $database)->query("SELECT * FROM pruebas");
    //$sqlConsultapruebas = new mysqli("localhost", "martinezanch", "contr@s3n54", "pruebadb")->query("SELECT * FROM pruebas");

    //Verifica errores
    if($sqlConsultausuarios === false){
    die("Error de consulta SQL: " . $conn->error);
    }


    if($sqlConsultausuarios->num_rows === 0) {
        echo ".No existen usuarios registrados.";
    }else{

    
        while ($fila = $sqlConsultausuarios->fetch_assoc()) {

                echo "ID: " . $fila["id_usuario"] . " Usuario: " . $fila["nombre"] . " - Email: " . $fila["correo"];
      
        ?>

        <table border="1">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Correo</th>
                <th>Teléfono</th>
                <th>Activo</th>
                <th>Fecha registro</th>
                <th>Último acceso</th>
                <th>Rol</th>
            </tr>

        
            <tr>
                <td><?php echo $fila["id_usuario"];      ?></td>
                <td><?php echo $fila["nombre"];          ?></td>
                <td><?php echo $fila["apellido"];        ?></td>
                <td><?php echo $fila["correo"];          ?></td>
                <td><?php echo $fila["telefono"];        ?></td>
                <td><?php echo $fila["activo"] ? "Sí" : "No"; ?></td>
                <td><?php echo $fila["fecha_registro"];  ?></td>
                <td><?php echo $fila["ultimo_acceso"] ?? "—"; ?></td>
                <td><?php echo $fila["id_rol"];          ?></td>
    
            </tr>

        </table>
    <?php
    }
}
?>



