<?php
    $host = "localhost";
    $user = "D_mar";
    $password = "!*ac(ZhCq*5LJGgE";
    $database = "repertrack_db";
    
    $conn = new mysqli ($host,$user, $password,$database );

    if ($conn ->   connect_error )  {

        die("Connection failed: " . $conn->connect_error);

    }


    $conn  -> set_charset ("utf8mb4");

echo " La conexion se ha estabecido correctamente<br><hr>";


?>